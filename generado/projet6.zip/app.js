const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const { Sequelize } = require('sequelize');//MYSQL
require("dotenv").config();

const path = require('path');
const DB_USER = "usernew32";//process.env.DB_USER;
const DB_PASSWORD = "usernew32"; //process.env.DB_PASSWORD;
const DB_HOST = "cluster0.1ikre6v.mongodb.net";//process.env.DB_HOST;
mongoose.connect(`mongodb+srv://${DB_USER}:${DB_PASSWORD}@${DB_HOST}/test?retryWrites=true&w=majority`,
  { useNewUrlParser: true,
    useUnifiedTopology: true })
  .then(() => console.log('Connexion à MongoDB réussie !'))
  .catch(() => console.log('Connexion à MongoDB échouée !'));

  /*const sequelize = new Sequelize(process.env.DB_NAME, process.env.DB_USER, process.env.DB_PASSWORD, {
    host: process.env.DB_HOST,
    dialect: 'mysql', // Tipo de base de datos que estamos utilizando
    logging: false,   // Puedes habilitar esto para ver las consultas SQL generadas
  });  */
  /*sequelize.authenticate()
  .then(() => {
    console.log('Conexión a la base de datos MySQL exitosa');
  })
  .catch(err => {
    console.error('Error al conectarse a la base de datos MySQL:', err);
  });  */


  const sauceRoutes = require("./routes/sauce.js");
  const userRoutes = require('./routes/user');  

const app = express();
app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content, Accept, Content-Type, Authorization');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, PATCH, OPTIONS');
    next();
  });
app.use(express.json());
app.use(bodyParser.json());  
app.use("/api/sauces", sauceRoutes);
app.use('/api/auth', userRoutes);
app.use('/images', express.static(path.join(__dirname, 'images')));
module.exports = app;